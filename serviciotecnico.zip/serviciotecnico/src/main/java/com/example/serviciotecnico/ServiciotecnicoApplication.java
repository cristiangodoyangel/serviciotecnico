package com.example.serviciotecnico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiciotecnicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiciotecnicoApplication.class, args);
	}

}
