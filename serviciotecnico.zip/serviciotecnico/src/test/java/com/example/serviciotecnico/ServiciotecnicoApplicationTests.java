package com.example.serviciotecnico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiciotecnicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
